# TalkAR
Augmented Reality based Android App for learning German language
